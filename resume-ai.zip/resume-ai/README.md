# ResumeAI
AI resume builder: 1 free resume, then a paid plan in INR (Razorpay). FastAPI + SQLite/Postgres.

    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    cp .env.example .env   # fill AI_API_KEY (Groq) and Razorpay TEST keys
    uvicorn app.main:app --reload --env-file .env

Health check: /healthz
