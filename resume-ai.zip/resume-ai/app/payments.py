import hashlib
import hmac

import httpx

from . import config


def create_order(amount_paise: int, receipt: str) -> dict:
    r = httpx.post(
        "https://api.razorpay.com/v1/orders",
        auth=(config.RAZORPAY_KEY_ID, config.RAZORPAY_KEY_SECRET),
        json={"amount": amount_paise, "currency": "INR", "receipt": receipt},
        timeout=20,
    )
    r.raise_for_status()
    return r.json()


def _hmac(secret: str, msg: bytes) -> str:
    return hmac.new(secret.encode(), msg, hashlib.sha256).hexdigest()


def verify_signature(order_id: str, payment_id: str, signature: str) -> bool:
    expected = _hmac(config.RAZORPAY_KEY_SECRET, f"{order_id}|{payment_id}".encode())
    return hmac.compare_digest(expected, signature or "")


def verify_webhook(body: bytes, signature: str) -> bool:
    expected = _hmac(config.RAZORPAY_WEBHOOK_SECRET, body)
    return hmac.compare_digest(expected, signature or "")
